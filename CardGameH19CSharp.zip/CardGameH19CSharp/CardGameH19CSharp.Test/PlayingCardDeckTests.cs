using Microsoft.VisualStudio.TestTools.UnitTesting;
using CardGameH19CSharp;

namespace CardGameH19CSharp.Test
{
    [TestClass]
    public class PlayingCardDeckTests
    {
        [TestMethod]
        public void TestMethod1()
        {
            //Arrange
            PlayingCardDeck cardDeck = new PlayingCardDeck();


            //Act
            //Method CreateDeckOfCards is called when creating an instance of the class


            //Assert
            Assert.AreEqual(52, cardDeck.DeckOfCards.Count);
        }
    }
}
